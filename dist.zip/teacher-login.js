// teacher-login.js - Teacher Authentication with Flask REST API

function togglePassword() {
    const passwordInput = document.getElementById('password');
    const showPasswordBtn = document.querySelector('.show-password');
    if (!passwordInput) return;

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        if (showPasswordBtn) showPasswordBtn.innerHTML = '<i class="fa-solid fa-eye-slash"></i>';
    } else {
        passwordInput.type = 'password';
        if (showPasswordBtn) showPasswordBtn.innerHTML = '<i class="fa-solid fa-eye"></i>';
    }
}

function forgotPassword(event) {
    event.preventDefault();
    alert('Teacher password recovery has been notified to CSMSS Academic Administration.');
}

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('teacherLoginForm');
    const loginButton = form ? form.querySelector('.login-button') : null;

    if (!form) return;

    // Create error message container
    let errorBox = document.getElementById('teacherErrorBox');
    if (!errorBox) {
        errorBox = document.createElement('div');
        errorBox.id = 'teacherErrorBox';
        errorBox.className = 'error-message';
        errorBox.style.display = 'none';
        form.parentNode.insertBefore(errorBox, form);
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        errorBox.style.display = 'none';
        errorBox.textContent = '';

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;

        if (!email || !password) {
            errorBox.innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> Please enter both email and password.';
            errorBox.style.display = 'flex';
            return;
        }

        const originalBtnHTML = loginButton.innerHTML;
        loginButton.disabled = true;
        loginButton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Logging in as Teacher...';

        try {
            const response = await fetch('/api/teacher/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                // Store teacher authentication
                localStorage.setItem('teacher_token', data.token);
                localStorage.setItem('token', data.token);
                localStorage.setItem('user_role', 'teacher');
                localStorage.setItem('teacher_info', JSON.stringify(data.user));

                loginButton.innerHTML = '<i class="fa-solid fa-check"></i> Welcome, Professor! Redirecting...';
                setTimeout(() => {
                    window.location.href = 'teacher-dashboard.html';
                }, 500);
            } else {
                loginButton.disabled = false;
                loginButton.innerHTML = originalBtnHTML;
                errorBox.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${data.error || 'Invalid credentials.'}`;
                errorBox.style.display = 'flex';
            }
        } catch (error) {
            console.error('Teacher login error:', error);
            loginButton.disabled = false;
            loginButton.innerHTML = originalBtnHTML;
            errorBox.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Connection error. Make sure the backend server is running.';
            errorBox.style.display = 'flex';
        }
    });
});

async function teacherLoginWithGoogle(customEmail) {
    let errorBox = document.getElementById('teacherErrorBox');
    if (!errorBox) {
        const form = document.getElementById('teacherLoginForm');
        errorBox = document.createElement('div');
        errorBox.id = 'teacherErrorBox';
        errorBox.className = 'error-message';
        errorBox.style.display = 'none';
        if (form) form.parentNode.insertBefore(errorBox, form);
    }
    if (errorBox) errorBox.style.display = 'none';

    const googleBtn = document.getElementById('googleTeacherLoginBtn');
    const originalText = googleBtn ? googleBtn.innerHTML : '';
    if (googleBtn) {
        googleBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Authenticating with Google...';
        googleBtn.disabled = true;
    }

    const email = customEmail || 'teacher@csmss.edu';
    const name = 'Prof. Kadam';

    try {
        const response = await fetch('/api/auth/google', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ email, name, role: 'teacher' })
        });

        const data = await response.json();
        if (response.ok && data.success) {
            localStorage.setItem('teacher_token', data.token);
            localStorage.setItem('token', data.token);
            localStorage.setItem('user_role', 'teacher');
            localStorage.setItem('teacher_info', JSON.stringify(data.user));

            if (googleBtn) {
                googleBtn.innerHTML = '<i class="fa-solid fa-circle-check"></i> Google Verified! Redirecting...';
            }
            setTimeout(() => {
                window.location.href = 'teacher-dashboard.html';
            }, 500);
        } else {
            if (googleBtn) {
                googleBtn.disabled = false;
                googleBtn.innerHTML = originalText;
            }
            if (errorBox) {
                errorBox.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${data.error || 'Google login failed.'}`;
                errorBox.style.display = 'flex';
            }
        }
    } catch (err) {
        console.error('Teacher Google login error:', err);
        if (googleBtn) {
            googleBtn.disabled = false;
            googleBtn.innerHTML = originalText;
        }
        if (errorBox) {
            errorBox.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Connection error during Google login.';
            errorBox.style.display = 'flex';
        }
    }
}
window.teacherLoginWithGoogle = teacherLoginWithGoogle;

